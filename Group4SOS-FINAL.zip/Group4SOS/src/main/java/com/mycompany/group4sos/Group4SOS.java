/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.group4sos;

/**
 *
 * @author Ulric
 */
public class Group4SOS {

    public static void main(String[] args) {
        new MenuPage().setVisible(true);        // BINAGO KO KIEL
    }
}
